TASK PRIME - Sync Tool

How to use:
1. Edit config.json
2. Double click TASK_PRIME.exe


No terminal will appear.
